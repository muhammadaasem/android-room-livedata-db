package com.roomlivedata;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class NewItemActivity extends AppCompatActivity {

    private  EditText  etCol1, etCol2, etCol3, etCol4;
    Bundle extras = new Bundle();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_item);
        etCol1 = findViewById(R.id.etCol1);
        etCol2 = findViewById(R.id.etCol2);
        etCol3 = findViewById(R.id.etCol3);
        etCol4 = findViewById(R.id.etCol4);


        final Button button = findViewById(R.id.save_item);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent reply = new Intent();
                if (TextUtils.isEmpty(etCol1.getText())) {
                    setResult(RESULT_CANCELED, reply);

                } else {
                    String c1,c2,c3,c4;
                    c1= etCol1.getText().toString();
                    c2= etCol2.getText().toString();
                    c3= etCol3.getText().toString();
                    c4= etCol4.getText().toString();

                    extras.putString("col1",c1);
                    extras.putString("col2",c2);
                    extras.putString("col3",c3);
                    extras.putString("col4",c4);


                    reply.putExtras(extras);
                    setResult(RESULT_OK, reply);
                }
                finish();
            }
        });
    }
}