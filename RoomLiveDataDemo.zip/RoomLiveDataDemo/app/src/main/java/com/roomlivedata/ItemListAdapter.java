package com.roomlivedata;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class ItemListAdapter extends RecyclerView.Adapter<ItemListAdapter.ItemViewHolder> {

    class ItemViewHolder extends RecyclerView.ViewHolder {
        private final TextView tvCol1,tvCol2,tvCol3,tvCol4;

        private ItemViewHolder(View itemView) {
            super(itemView);
            tvCol1 = itemView.findViewById(R.id.tvCol1);
            tvCol2 = itemView.findViewById(R.id.tvCol2);
            tvCol3 = itemView.findViewById(R.id.tvCol3);
            tvCol4 = itemView.findViewById(R.id.tvCol4);
        }
    }

    private List<Item> myItems;
    private final LayoutInflater myInflater;

    ItemListAdapter(Context context) { myInflater = LayoutInflater.from(context); }

    @Override
    public ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = myInflater.inflate(R.layout.item_layout, parent, false);
        return new ItemViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ItemViewHolder holder, int position) {
        Item current = myItems.get(position);
        holder.tvCol1.setText(current.mCol1_id);
        holder.tvCol2.setText(current.mCol2);
        holder.tvCol3.setText(current.mCol3);
        holder.tvCol4.setText(current.mCol4);
    }

    @Override
    public int getItemCount() {
        if (myItems != null)
            return myItems.size();
        else return 0;
    }

    void setItems(List<Item> items){
        myItems = items;
        notifyDataSetChanged();
    }
}