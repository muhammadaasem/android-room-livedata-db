package com.roomlivedata;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static final int REQUEST_CODE = 1;
    private ItemViewModel myItemViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);

        RecyclerView myRecyclerView = findViewById(R.id.recycleview);
        final ItemListAdapter myAdapter = new ItemListAdapter(this);
        myRecyclerView.setAdapter(myAdapter);
        myRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        myItemViewModel = ViewModelProviders.of(this).get(ItemViewModel.class);
        myItemViewModel.getAllItems().observe(this, new Observer<List<Item>>() {

            @Override
            public void onChanged(@Nullable final List<Item> items) {
                myAdapter.setItems(items);
            }

        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.my_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.add_item:
                Intent intentNewItemActivity = new Intent(MainActivity.this, NewItemActivity.class);
                startActivityForResult(intentNewItemActivity, REQUEST_CODE);
                break;
        }
        return false;
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        String c1, c2, c3, c4;
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK) {


            c1=data.getExtras().getString("col1");
            c2=data.getExtras().getString("col2");
            c3=data.getExtras().getString("col3");
            c4=data.getExtras().getString("col4");

            Item item = new Item(c1,c2,c3,c4);
            myItemViewModel.insert(item);

        }

    }

}